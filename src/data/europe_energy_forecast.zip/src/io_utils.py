# io_utils placeholder
